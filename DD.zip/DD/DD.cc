/*
 * DD.cc
 *
 *  Created on: Jan 25, 2020
 *      Author: Mostafaie
 */
#include <omnetpp.h>
#include <string.h>
#include <vector>
#include "DD_m.h"
using namespace omnetpp;
using namespace std;
struct Grad{
    int nodeIndex;
    double datarate;
//    double duration;
};
struct IntCach{
    int Type;
//    int Sink;
    double Timestamp;
    double duration;
    vector<Grad> Gradient;
};
void Update(vector<IntCach> Cache,double time){
    vector<IntCach> TempCache;
    for (int i = 0; i < Cache.size(); i++) {
        if(Cache[i].Timestamp + Cache[i].duration < time)TempCache.push_back(Cache[i]);
    }
    Cache.clear();
    Cache = TempCache;
}

IntCach Insert(Interest *IntMsg){
    IntCach tempInt;
    Grad tempGrad;
//    tempInt.Sink = -1;
    tempInt.Type = IntMsg->getType();
    tempInt.Timestamp = IntMsg->getTimestamp();
    tempInt.duration = IntMsg->getExpiresAt() - IntMsg->getTimestamp();
    tempGrad.datarate = IntMsg->getInterval();
//    tempGrad.duration = tempInt.duration;
    tempGrad.nodeIndex = IntMsg->getIndex();
    tempInt.Gradient.push_back(tempGrad);
    return tempInt;
};
bool Match(vector<IntCach> Cache,Interest *IntMsg){
    bool match = false;
//    BC = true;
    for (int i = 0; i < Cache.size(); i++) {
//        if(Cache[i].Timestamp == IntMsg->getTimestamp() && Cache[i].Type == IntMsg->getType())
//            BC = false;
        if(Cache[i].Type == IntMsg->getType()){
            for (int j = 0; j < Cache[i].Gradient.size(); j++) {
                if(Cache[i].Gradient[j].nodeIndex == IntMsg->getIndex()){
                    Cache[i].Gradient[j].datarate = IntMsg->getInterval();
                    Cache[i].Timestamp = IntMsg->getTimestamp();
                    Cache[i].duration = IntMsg->getExpiresAt() - IntMsg->getTimestamp();
                    match = true;
                }

            }
            if(!match){
                Grad tempGrad;
                tempGrad.datarate = IntMsg->getInterval();
            //    tempGrad.duration = tempInt.duration;
                tempGrad.nodeIndex = IntMsg->getIndex();
                Cache[i].Gradient.push_back(tempGrad);
                match = true;
            }
        }
    }
    return match;
};

class Node : public cSimpleModule{
private:
    string Type[3] = {"Animal", "Human", "vehicles"};
    string ASubType[3] = {"Tiger", "Lion", "Wolf"};
    string HSubType[3] = {"Man", "Woman", "Child"};
    string VSubType[3] = {"Car", "Truck", "Motorcycle"};

//    enum{Animal = 0, Human = 1, vehicles = 3}Type;
//    enum{Tiger = 0, Lion = 1, Wolf = 2}ASubType;
//    enum{Man = 10, Woman = 11, Child = 12}HSubType;
//    enum{Car = 20, Truck = 21, Motorcycle = 22}VSubType;
//    enum{Source = 0, Dead = 1}type;
//    simsignal_t stateSignal;
    simsignal_t arrivalSignal;
    simsignal_t SendSignal;
    simsignal_t Power;
    double x, y;//مختصات نود
    const double propagationSpeed = 299792458.0; // سرعت انتشار سیگنال
    double radioDelay;                          // مدت ارسال
    int Dist;
    int InPkLen;
    int EvPkLen;
    cModule *temp;                              //  ماژول موقت جهت ارسال به نودهای دیگر
    int N;//تعداد نودها
    int M;// مساحت محیط
    int RecvCount = 0;// شمارنده تعداد بسته های دریافتی
    int SendCount = 0;// شمارنده تعداد بسته های ارسالی
    bool BC;
    vector<int> Indexes;
    int DataRate = 100;
    vector<IntCach> Cache;
//    unsigned int lastTime = 0;
//    cLongHistogram BatteryStats;
//    cOutVector BatteryVector;

    /*          پارامترهای مربوط به انرژی       */
    double Battery;
    double E_Tx_In;
    double E_Rx_In;
    double E_Tx_Ev;
    double E_Rx_Ev;
    double E_elec = 50e-9;//J/Sec
    double E_Amp = 10e-12;//J/b/m2
public:
   Node();
   virtual ~Node();

protected:
    void IntBroadCast(int type,double interval,Range Region,double timestamp,double expiresAt);// یک داده را برای نودهای همسایه برودکست می کند.
    void EventBroadCast(int index, int type,int instance);// یک داده را برای نودهای همسایه برودکست می کند.
//    void send(int SRC,int Data_Hops);
    virtual Interest *InterestMessage(int type,double interval,Range Region,double timestamp,double expiresAt);// تولید پکت ارسالی
    virtual DataEvent *EventMessage(int index,int type,int instance);// تولید پکت ارسالی
    virtual void initialize() override;// تابع اولیه در ابتدای کار اجرا می شود
    virtual void handleMessage(cMessage *msg) override;// تابع دریافت و ارسال پیام
    virtual void refreshDisplay() const override;
    virtual void finish() override;// تابع پایان کار
};
Define_Module(Node);
Node::Node(){

}
Node::~Node(){

}
void Node::refreshDisplay() const{
//    getDisplayString().setTagArg("t", 2, "#808000");
//    if (type == On) {
//        getDisplayString().setTagArg("i", 1, "Green");
////        getDisplayString().setTagArg("t", 0, "Alive");
//        }
//    else if (type == Dead) {
//            getDisplayString().setTagArg("i", 1, "Black");
//            getDisplayString().setTagArg("t", 0, "Dead");
//        }
}
void Node::initialize(){
    N = par("numNodes");// گرفتن پارامتر N از NED فایل

    M = par("M");// گرفتن پارامتر M از NED فایل

    x = par("x").doubleValue();// گرفتن پارامتر x از NED فایل

    y = par("y").doubleValue();// گرفتن پارامتر y از NED فایل

    Dist = par("Distance");// گرفتن پارامتر Distance از NED فایل

    InPkLen = par("InPkLen");// گرفتن طول بسته از فایل NED

    EvPkLen = par("EvPkLen");// گرفتن طول بسته از فایل NED

    E_Rx_Ev = EvPkLen * E_elec; // محاسبه مقدار انرژی مصرفی برای هر بار دریافت

    E_Tx_Ev = (EvPkLen * E_elec) + (EvPkLen * E_Amp * (Dist * Dist));// محاسبه مقدار انرژی مصرفی برای هر بار ارسال

    E_Rx_In = InPkLen * E_elec; // محاسبه مقدار انرژی مصرفی برای هر بار دریافت

    E_Tx_In = (InPkLen * E_elec) + (InPkLen * E_Amp * (Dist * Dist));// محاسبه مقدار انرژی مصرفی برای هر بار ارسال

    radioDelay = Dist/propagationSpeed;// تأخیر ارسال رادیویی

    Battery = par("Energy").doubleValue();// دریافت مقدار انرژی از INI فایل

    RecvCount = 0; // مقداردهی اولیه شمارنده بسته
    SendCount = 0; // مقداردهی اولیه شمارنده بسته


    WATCH((int&)RecvCount);
    WATCH((int&)SendCount);
    WATCH((double&)Battery);
//    WATCH((int&)(Cache.size()));
    arrivalSignal = registerSignal("arrival");// گرفتن پارامتر تعداد هاپ از فایل NED
    SendSignal = registerSignal("sendSig");// گرفتن پارامتر تعداد هاپ از فایل NED
    Power = registerSignal("Power");// گرفتن پارامتر وضعیت انرژی از فایل NED
    emit(Power,Battery);// ریختن مقدار باتری در سیگنال
    emit(arrivalSignal,RecvCount);// ریختن هاپ در سیگنال
    emit(SendSignal,SendCount);// ریختن هاپ در سیگنال

//    arrivalSignal = registerSignal("arrival");// گرفتن پارامتر تعداد هاپ از فایل NED
//    Power = registerSignal("Power");// گرفتن پارامتر تعداد هاپ از فایل NED
//    stateSignal = registerSignal("state");// گرفتن پارامتر وضعیت از فایل NED
//    type = On;
//    emit(stateSignal,type);// ریختن مقدار باتری در سیگنال
//    emit(Power,Battery);// ریختن مقدار باتری در سیگنال
//    emit(arrivalSignal,hopCount);// ریختن هاپ در سیگنال
}
void Node::handleMessage(cMessage *msg){
    if(Battery >= (E_Rx_Ev + E_Tx_Ev)){
        RecvCount++;
    if(msg->getKind() == 3)Cache.clear();
    else if(msg->getKind() == 1){// Receive interest message
        Interest *IntMsg = check_and_cast<Interest *>(msg);
        Battery = Battery - E_Rx_In;// کاهش انرژی به دلیل دریافت بسته


//        Update(Cache, simTime().dbl());
        if(Cache.size() <= 0){
            Cache.push_back(Insert(IntMsg));
            BC = true;
        }
        else if(Cache.size() > 0){
//            EV << Cache.size() <<endl;
            if(!Match(Cache,IntMsg)){
                Cache.push_back(Insert(IntMsg));
                BC =true;
            }
        }
        if(BC){
            IntBroadCast(IntMsg->getType(), IntMsg->getInterval(), IntMsg->getRegion(), IntMsg->getTimestamp(), IntMsg->getExpiresAt());
            Battery = Battery - E_Tx_In;// کاهش انرژی به دلیل ارسال بسته
            SendCount++;
            if(IntMsg->getRegion().First.x <= x && IntMsg->getRegion().First.y <= y
                    && IntMsg->getRegion().Second.x >= x && IntMsg->getRegion().Second.y >= y){

                for (int i = 0; i < Cache.size(); i++) {
                    if(Cache[i].Type == IntMsg->getType()){
//                        DataRate = 100;
//                        for (int j = 0; j < Cache[i].Gradient.size(); j++) {
//                            if(Cache[i].Gradient[j].datarate < DataRate)DataRate = Cache[i].Gradient[j].datarate;
//                        }
                        for (int j = 0; j < Cache[i].Gradient.size(); j++) {
//                            if(Cache[i].Gradient[j].datarate <= DataRate){
                                DataEvent *Msg = EventMessage(Cache[i].Gradient[j].nodeIndex,Cache[i].Type, intuniform(0, 2));
                                Msg->setKind(0); // self Message
                                if(IntMsg->getTimestamp() + IntMsg->getInterval() > simTime().dbl())
                                    scheduleAt(IntMsg->getTimestamp() + IntMsg->getInterval(), Msg);//زمانبندی برای ارسال بسته خط بالا به نودها
//                                EV << "Self Message" <<endl;
//                            }
                        }
                    }
                }
            }
        }
        BC = false;

        cMessage *Msg = new cMessage();// = Interest(Cache[i].Gradient[j].nodeIndex,Cache[i].Type, intuniform(0, 2));
        Msg->setKind(3); // self Message
        if(IntMsg->getExpiresAt() > simTime().dbl())
            scheduleAt(IntMsg->getExpiresAt(), Msg);//زمانبندی برای ارسال بسته خط بالا به نودها
//        else    scheduleAt(simTime()+ intuniform(0, 10,rng), Msg);//زمانبندی برای ارسال بسته خط بالا به نودها


    }
    else if(msg->getKind() == 0){
        DataEvent *EventMsg = check_and_cast<DataEvent *>(msg);
        EventBroadCast(EventMsg->getIndex(), EventMsg->getType(), EventMsg->getInstance());
        Battery = Battery - E_Tx_Ev;// کاهش انرژی به دلیل ارسال بسته
        SendCount++;

        for (int i = 0; i < Cache.size(); i++) {
            if(Cache[i].Timestamp + Cache[i].duration > simTime().dbl()){
//                DataRate = 100;
//                for (int j = 0; j < Cache[i].Gradient.size(); j++) {
//                    if(Cache[i].Gradient[j].datarate < DataRate)DataRate = Cache[i].Gradient[j].datarate;
//                }
                for (int j = 0; j < Cache[i].Gradient.size(); j++) {
//                    if(Cache[i].Gradient[j].datarate <= DataRate){
                        DataEvent *Msg = EventMessage(Cache[i].Gradient[j].nodeIndex,Cache[i].Type, intuniform(0, 2));
                        Msg->setKind(0); // self Message
                        if(Cache[i].Timestamp + Cache[i].duration > simTime().dbl() + Cache[i].Gradient[j].datarate)
                            scheduleAt(simTime().dbl() + Cache[i].Gradient[j].datarate, Msg);//زمانبندی برای ارسال بسته خط بالا به نودها
//                    }
                }
            }
        }
    }
    else if(msg->getKind() == 2){// Receive EventData message
        DataEvent *EventMsg = check_and_cast<DataEvent *>(msg);
        Battery = Battery - E_Rx_Ev;// کاهش انرژی به دلیل دریافت بسته

        if(EventMsg->getIndex() == getIndex()){
        for (int i = 0; i < Cache.size(); i++) {
            if(Cache[i].Type == EventMsg->getType()){
//                DataRate = 100;
//                for (int j = 0; j < Cache[i].Gradient.size(); j++) {
//                    if(Cache[i].Gradient[j].datarate < DataRate)DataRate = Cache[i].Gradient[j].datarate;
//                }
                for (int j = 0; j < Cache[i].Gradient.size(); j++) {
//                    if(Cache[i].Gradient[j].datarate <= DataRate){
                        EventBroadCast(Cache[i].Gradient[j].nodeIndex, EventMsg->getType(), EventMsg->getInstance());
                        Battery = Battery - E_Tx_Ev;// کاهش انرژی به دلیل ارسال بسته
                        SendCount++;
//                         }
                }
            }
        }
    }

    }
    }
    emit(Power,Battery);// ریختن مقدار باتری در سیگنال
    emit(arrivalSignal,RecvCount);// ریختن هاپ در سیگنال
    emit(SendSignal,SendCount);// ریختن هاپ در سیگنال

}
void Node::finish(){
    emit(Power,Battery);// ریختن مقدار باتری در سیگنال
    emit(arrivalSignal,RecvCount);// ریختن هاپ در سیگنال
    emit(SendSignal,SendCount);// ریختن هاپ در سیگنال
}
Interest *Node::InterestMessage(int type,double interval,Range Region,double timestamp,double expiresAt){
    Interest *msg = new Interest();
    msg->setIndex(getIndex());
    msg->setType(type);
    msg->setInterval(interval);
    msg->setRegion(Region);
    msg->setTimestamp(timestamp);
    msg->setExpiresAt(expiresAt);
    msg->setKind(1); // Interest ID
    return msg;
}
DataEvent *Node::EventMessage(int index,int type,int instance){
    DataEvent *msg = new DataEvent();
    msg->setIndex(index);
    msg->setType(type);
    msg->setInstance(instance);
    Place Temp;
    Temp.x = x;
    Temp.y = y;
    msg->setLocation(Temp);
    msg->setIntensity(uniform(0,1));
    msg->setConfidence(uniform(0,1));
    msg->setTimestamp(simTime().dbl());
    msg->setKind(2); // Interest ID
    return msg;
};
void Node::IntBroadCast(int type,double interval,Range Region,double timestamp,double expiresAt){
    for (int i = 0; i < N; i++) {
        if(i!= getIndex()){

            temp = getModuleByPath(("node[" + std::to_string(i) + "]").c_str());
            if(!temp)
                    throw cRuntimeError(("node[" + std::to_string(i) + "] not found.").c_str());
            double XT = temp->par("x").doubleValue();
            double YT = temp->par("y").doubleValue();
            double Tdist = std::sqrt((x-XT) * (x-XT) + (y-YT) * (y-YT));// فاصله از نود i تا سینک
            if(Dist >= Tdist){
                Interest *Msg = InterestMessage(type,interval,Region,timestamp,expiresAt);
                Msg->setRegion(Region);
                Msg->setTimestamp(timestamp);
                Msg->setExpiresAt(expiresAt);
                Msg->setKind(1);
                sendDirect(Msg, Tdist/propagationSpeed,0,temp->gate("in"));//ارسال بسته خط بالا به نودها
            }
        }
    }
}
void Node::EventBroadCast(int index, int type,int instance){
    if(index == -1){
        temp = getModuleByPath("sink");
        if(!temp)
                throw cRuntimeError("sink not found.");
        double XT = temp->par("x").doubleValue();
        double YT = temp->par("y").doubleValue();
        double Tdist = std::sqrt((x-XT) * (x-XT) + (y-YT) * (y-YT));// فاصله از نود i تا سینک
        DataEvent *Msg = EventMessage(index, type, instance);
        Msg->setKind(2);
        sendDirect(Msg, Tdist/propagationSpeed,0,temp->gate("in"));//ارسال بسته خط بالا به نودها
    }
    for (int i = 0; i < N; i++) {
        if(i!= getIndex()){

            temp = getModuleByPath(("node[" + std::to_string(i) + "]").c_str());
            if(!temp)
                    throw cRuntimeError(("node[" + std::to_string(i) + "] not found.").c_str());
            double XT = temp->par("x").doubleValue();
            double YT = temp->par("y").doubleValue();
            double Tdist = std::sqrt((x-XT) * (x-XT) + (y-YT) * (y-YT));// فاصله از نود i تا سینک
            if(Dist >= Tdist){
                DataEvent *Msg = EventMessage(index, type, instance);
                Msg->setKind(2);
                sendDirect(Msg, Tdist/propagationSpeed,0,temp->gate("in"));//ارسال بسته خط بالا به نودها
            }
        }
    }
}

//void Node::send(int SRC,int Data_Hops){
//
//};
class Sink : public cSimpleModule{
private:
    simsignal_t arrivalSignal;

    string Type[3] = {"Animal", "Human", "vehicles"};
    string ASubType[3] = {"Tiger", "Lion", "Wolf"};
    string HSubType[3] = {"Man", "Woman", "Child"};
    string VSubType[3] = {"Car", "Truck", "Motorcycle"};

    double x, y;//مختصات سینک
    const double propagationSpeed = 299792458.0; // سرعت انتشار سیگنال
    double radioDelay;                          // مدت ارسال
    int Dist;
    cModule *temp;                              //  ماژول موقت جهت ارسال به نودهای دیگر
    int N;//تعداد نودها
    int M;// مساحت محیط
    int Counter = 0; // شمارنده بسته
    int TempCount = 1;
    int End = 0;
public:
    Sink();
    virtual ~Sink();
protected:
    void BroadCast(int type,double interval,Range Region,double timestamp,double expiresAt);
    virtual Interest *InterestMessage(int type,double interval);// تولید پکت ارسالی
    virtual void initialize() override;// تابع اولیه در ابتدای کار اجرا می شود
    virtual void handleMessage(cMessage *msg) override;// تابع دریافت و ارسال پیام
    virtual void finish() override;// تابع پایان کار
};
Define_Module(Sink);
Sink::Sink(){

}
Sink::~Sink(){

}

void Sink::initialize(){
    N = par("numNodes");// گرفتن پارامتر N از NED فایل

    M = par("M"); // گرفتن پارامتر M از NED فایل

    x = par("x").doubleValue();// گرفتن پارامتر x از NED فایل

    y = par("y").doubleValue();// گرفتن پارامتر y از NED فایل

    Dist = par("Distance");// گرفتن پارامتر Distance از NED فایل

    radioDelay = Dist/propagationSpeed;// تأخیر ارسال رادیویی

    WATCH((int&)Counter);

    WATCH((int&)End);

    arrivalSignal = registerSignal("arrival");// گرفتن پارامتر تعداد هاپ از فایل NED

    Interest *Msg = InterestMessage(intuniform(0, 2), 1);//تولید پیام برودکست در ابتدای کار

    Msg->setExpiresAt(simTime().dbl()+10);

    Msg->setKind(0); // self Message

    scheduleAt(simTime(), Msg);//زمانبندی برای ارسال بسته خط بالا به نودها

    emit(arrivalSignal,Counter);// ریختن هاپ در سیگنال

//    EV << "Interest to " + Type + " in the Area on: "+ Msg->getRegion().First.x + ", "+Msg->getRegion().First.y + " And " + Msg->getRegion().Second.x + ", "+Msg->getRegion().Second.y + "." << endl;


}
void Sink::handleMessage(cMessage *msg){
    if (msg->getKind() == 0) {//self message Kind==0

        Interest *RecvMsg = check_and_cast<Interest *>(msg);//تبدیل پیام دریافتی به فرمت مشخص شده


        EV << ("Interest to " + Type[RecvMsg->getType()] + " in the Area on: "+ std::to_string(RecvMsg->getRegion().First.x) + ", "+std::to_string(RecvMsg->getRegion().First.y) +
                " And " + std::to_string(RecvMsg->getRegion().Second.x) + ", "+std::to_string(RecvMsg->getRegion().Second.y) + ".").c_str() << endl;

        BroadCast(RecvMsg->getType(), RecvMsg->getInterval(), RecvMsg->getRegion(), RecvMsg->getTimestamp(), RecvMsg->getExpiresAt());

        Interest *Msg = InterestMessage(intuniform(0, 2),1/*uniform(0, 1, 2)*/);//تولید پیام برودکست در ابتدای کار


        Msg->setTimestamp(int(RecvMsg->getExpiresAt()));
        Msg->setExpiresAt(intuniform(Msg->getTimestamp(),Msg->getTimestamp() + 20,2));

        Msg->setKind(0); // self Message

        if(End < 10) scheduleAt(Msg->getTimestamp(), Msg);//زمانبندی برای ارسال بسته خط بالا به نودها
        if(TempCount !=0){
            End = 0;
        }
        else{
           End++;
        }
        TempCount =0;

    }
    else if(msg->getKind() == 2){
        TempCount++;
        Counter++;
        bubble("Data Delivered :)");
    }
    emit(arrivalSignal,Counter);// ریختن هاپ در سیگنال

}
void Sink::BroadCast(int type,double interval,Range Region,double timestamp,double expiresAt){
    for (int i = 0; i < N; i++) {
        temp = getModuleByPath(("node[" + std::to_string(i) + "]").c_str());
    if(!temp)
        throw cRuntimeError(("node[" + std::to_string(i) + "] not found.").c_str());
    double XT = temp->par("x").doubleValue();
    double YT = temp->par("y").doubleValue();
    double Tdist = std::sqrt((x-XT) * (x-XT) + (y-YT) * (y-YT));// فاصله از نود i تا سینک
    if(Dist >= Tdist){
        Interest *Msg = InterestMessage(type, interval);
        Msg->setKind(1);
        Msg->setRegion(Region);
        Msg->setTimestamp(timestamp);
        Msg->setExpiresAt(expiresAt);
        sendDirect(Msg, Tdist/propagationSpeed,0,temp->gate("in"));//ارسال بسته خط بالا به نودها
        }
    }
}
void Sink::finish(){
    emit(arrivalSignal,Counter);// ریختن هاپ در سیگنال
}
Interest *Sink::InterestMessage(int type,double interval){
    Interest *msg = new Interest();
    msg->setIndex(-1);
    msg->setType(type);
    msg->setInterval(interval);
    Range temp;
    temp.First.x = intuniform(0,100,1);
    temp.First.y = intuniform(0,100,2);
//    temp.Second.x = temp.First.x + 50;
//    temp.Second.y = temp.First.y + 50;
    temp.Second.x = intuniform(0, 100,3);
    temp.Second.y = intuniform(0, 100,3);
    if(temp.First.x > temp.Second.x){
        int xtemp = temp.First.x;
        temp.First.x = temp.Second.x;
        temp.Second.x = xtemp;
    }
    if(temp.First.y > temp.Second.y){
        int ytemp = temp.First.y;
        temp.First.y = temp.Second.y;
        temp.Second.y = ytemp;
    }
    msg->setRegion(temp);
    msg->setTimestamp(simTime().dbl());
    msg->setExpiresAt(uniform(simTime().dbl()+5, simTime().dbl()+60));
    msg->setKind(1); // Interest ID
    return msg;
}
