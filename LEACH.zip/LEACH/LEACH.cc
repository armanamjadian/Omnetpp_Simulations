/*
 * LEACH.cc
 *
 *  Created on: Jan 9, 2020
 *      Author: Armanak
 */
#include <string.h>
#include <omnetpp.h>
#include <algorithm>
#include "LEACH_m.h"
using namespace omnetpp;
struct CH{
    int ID=-1;
    int Dist=1000;
};
double CalcP(int r, int k, double n){
    return k/(n-(r*k));
}
double CalcTn(int r, double P, bool Ct){
    if(!Ct) return P/(1-(P*fmod(r,(1/P))));
    else return 0;
}
int CalcKopt(int N,double e_fs,double e_mp,int M,int d_to_BS){
    return round((sqrt(N) / sqrt(2 * PI))*(sqrt(e_fs / e_mp))*(M / (pow(d_to_BS, 2))));
}

class Node : public cSimpleModule{
private:
    // Time Slots
    double SetupTime;// = 1/(K+1)
    double KSlotTime=0;
    double schedule =0;
//    double SlotTime;
    // Node Spec
    int DefultDataCount = 3;
    int DataCount;
    int N;// = 6;
    int K;
    int M;// = 100;
    int r=0;
    CH *CHCands;// = new CH[N];
    CH *CHs;
    double P;
    int Count=0;
    int CountK=0;
    int members=0;
    double D_to_BS = 75;
    double n;
    int ClusterId;
    //Energy
    double e_fs = 10e-12;
    double e_mp = 1.3e-15;
    bool Ct = false;
    bool CHRound = false;
    bool Dead = false;
    double SlotTime = 0;
    double radioDelay;
//    cPar *pkLenBits;
    cModule *temp;
//    SpinMsg *Msg;
    cMessage *endTxEvent;
    bool Candid = false;
int CHNum=-1;
double CHDist=1000;
    enum{Idle = 0, Adv = 1, Join = 2, Form = 3,Data=4, Setup =5}type;
    simsignal_t stateSignal;
    simtime_t duration;
    simtime_t events;
//    const int numNode = par("numNodes");
//    int *IDs;// = new int[numNode];
//    double* IDsSlotTime;
//    int HopCount;
    double x, y;
    double txRate;
    const double propagationSpeed = 299792458.0;
     double Dist;

    /* Graphical Variables */
     double ringMaxRadius;// = 200;// = par("Distance");// in m
     double circlesMaxRadius;// = 250;// = par("Distance"); // in m
     double AnimationSpeed ;// = par("AnimationSpeed");
    cMessage *lastPacket = nullptr; // a copy of the last sent message, needed for animation
    bool last ;
    mutable cRingFigure *transmissionRing = nullptr; // shows the last packet
    mutable std::vector<cOvalFigure *> transmissionCircles; // ripples inside the packet ring

public:
   Node();
   virtual ~Node();

protected:
   bool SetupPhase();
   double GetSchedule();
    virtual LeachMsg *generateMessage(std::string Type, int src,int dest);
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    virtual void refreshDisplay() const override;
    virtual void finish() override;
};
Define_Module(Node);
Node::Node(){
    endTxEvent = nullptr;

}
Node::~Node(){
    delete lastPacket;
    cancelAndDelete(endTxEvent);
}
void Node::initialize(){

    DataCount = DefultDataCount;

    last =false;

    type = Idle;

    Ct = false;

    Dead = false;

    N = par("numNodes");

    M = par("M");

    // Display
    ringMaxRadius = par("Distance");// in m
    circlesMaxRadius = par("Distance"); // in m
    AnimationSpeed = par("AnimationSpeed");
    Dist = par("Distance");
    // /Display
    txRate = par("txRate");
//    database[getIndex()] = N;
    radioDelay = Dist / propagationSpeed;
    SlotTime = (radioDelay);
//    KSlotTime =((N*SlotTime)/K);
    duration = 0;
    endTxEvent = new cMessage("send/endTx");
  //  SetupPhase();
    x = par("x").doubleValue();
    y = par("y").doubleValue();
//    n = uniform(0, CalcP(r, K, N));
    stateSignal = registerSignal("state");
    emit(stateSignal,type);
    WATCH((int&)type);
    SetupTime = 2e-06;

    //EV << "N: " << N << ", and Ct : "<< Ct << endl;
    Candid = SetupPhase();
    //KSlotTime = DefultDataCount * SlotTime;//((1e-4)-SetupTime)/K;
    if(Candid){
        EV << "K: " << K << ", T(n): " << CalcTn(r, P, Ct) << ", and n : "<< n << endl;
        for(int i = 0 ; (i< N); i++){
            temp = getModuleByPath(("node[" + std::to_string(i) + "]").c_str());
             if(!temp)
                     throw cRuntimeError(("node[" + std::to_string(i) + "] not found.").c_str());

            if(i!= getIndex()){
                LeachMsg *Msg = generateMessage("Idle",getIndex(),i);
                lastPacket = Msg->dup();
                cMessage *msg = check_and_cast<cMessage *>(Msg);
 //               scheduleAt(simTime()+radioDelay, msg);
                scheduleAt(SetupTime/6, msg);
            }
        }
    }
    CHs = new CH[K];
    CHCands = new CH[N];
    Count =0;
}
void Node::handleMessage(cMessage *msg){
    last = false;

    LeachMsg *ttmsg = check_and_cast<LeachMsg *>(msg);
    if(ttmsg->getMsgType() == Idle){
        DataCount  = DefultDataCount;
//        IDs = new int[N];
//        IDsSlotTime = new double[N];
        members = 0;
            type = Adv;
            emit(stateSignal,type);
            temp = getModuleByPath(("node[" + std::to_string(ttmsg->getDestination()) + "]").c_str());
                  if(!temp)
                     throw cRuntimeError(("node[" + std::to_string(ttmsg->getDestination()) + "] not found.").c_str());

                  LeachMsg *Msg = generateMessage("Adv",getIndex(),ttmsg->getDestination());
                  sendDirect(Msg, (SetupTime/6),duration,temp->gate("in"));
//                  sendDirect(Msg, radioDelay,duration,temp->gate("in"));
//                  cancelEvent(endTxEvent);
////                  sendDelayed(endTxEvent, 0.1, "in$o");
//
////                  scheduleAt(simTime()+radioDelay+duration, endTxEvent);
//                  //Sleep(0.2);
//
//                  scheduleAt((2*SetupTime/3), endTxEvent);
//
//                  if (transmissionRing != nullptr) {
//                          last = true;
//                              delete lastPacket;
//                              lastPacket = Msg->dup();
//                          }

        }
    else if(ttmsg->getMsgType() == Adv){
        if(ttmsg->getSource() != ttmsg->getDestination()){
        CHCands[Count].ID = ttmsg->getSource();


        LeachMsg *Msg = generateMessage("Adv",getIndex(),getIndex());

        if(Count ==0)scheduleAt(simTime()+(SetupTime/12), Msg);

        Count++;

        }
        else{


            for (int i = 0; i < K; i++) {
                for (int j = 0; j < Count; j++) {
                    if((CHCands[j].ID  >=0)&& ((CHCands[j].ID < CHs[i].ID )|| (CHs[i].ID < 0))){
                        CHs[i] = CHCands[j];
                        CHCands[j].ID = -1;
//                        CHCands[j].Dist = 1000;
                    }
                }
                EV << "K:" << K << "\t Count: " << Count << "\t CHRound:" << CHs[i].ID <<endl;

            }
//            if(Candid && (getIndex() < CHNum))CHNum = getIndex();
//            if(getIndex() != CHNum){
            for (int var = 0; var < K; var++) {
                if(CHs[var].ID == getIndex()){
                    CHNum = getIndex();
                    CHRound = true;
                }
//                if (!Candid || (Candid && CHs[var].ID < getIndex())) {
                if(!CHRound){


                temp = getModuleByPath(("node[" + std::to_string(CHs[var].ID) + "]").c_str());

                 if(!temp)
                     throw cRuntimeError(("node[" + std::to_string(CHs[var].ID) + "] not found.").c_str());

                 double XT = temp->par("x").doubleValue();
                 double YT = temp->par("y").doubleValue();
                 double Tdist = std::sqrt((x-XT) * (x-XT) + (y-YT) * (y-YT));

                 if(Tdist<CHDist){
                     CHDist = Tdist;
                     CHNum = CHs[var].ID;
                 }
            }
            }
            if (!CHRound){
//            EV << "K:" << K << endl << "Count :" << Count<<endl <<  "CHNUM: " << CHNum <<endl;
            type = Join;
            emit(stateSignal,type);
            temp = getModuleByPath(("node[" + std::to_string(CHNum) + "]").c_str());
            if(!temp)
               throw cRuntimeError(("node[" + std::to_string(CHNum) + "] not found.").c_str());
            LeachMsg *Msg = generateMessage("Join",getIndex(),CHNum);
            sendDirect(Msg, (SetupTime/12),duration,temp->gate("in"));
            }
//                     sendDirect(Msg, radioDelay,duration,temp->gate("in"));
//                     cancelEvent(endTxEvent);
//                     scheduleAt(simTime()+radioDelay+duration, endTxEvent);
        //                              if (transmissionRing != nullptr) {
        //                                      last = true;
        //                                          delete lastPacket;
        //                                          lastPacket = Msg->dup();
        //                                      }
            Count=0;
//        }
        }
    }
    else if(ttmsg->getMsgType() == Join){
        CHNum = getIndex();
//         IDs[members] = ttmsg->getSource();
        members++;
         Ct = true;
         CHRound = true;
         type = Form;
         emit(stateSignal,type);
         temp = getModuleByPath(("node[" + std::to_string(ttmsg->getSource()) + "]").c_str());
             if(!temp)
                 throw cRuntimeError(("node[" + std::to_string(ttmsg->getSource()) + "] not found.").c_str());
             LeachMsg *Msg = generateMessage("Form",getIndex(),ttmsg->getSource());
             Msg->setData(members-1);
             sendDirect(Msg, (SetupTime/6),duration,temp->gate("in"));
//             EV << "MEMBERS:" << members <<endl;


//             sendDirect(Msg, radioDelay,duration,temp->gate("in"));
//             cancelEvent(endTxEvent);
//             scheduleAt(simTime()+radioDelay+duration, endTxEvent);
             //                       if (transmissionRing != nullptr) {
             //                                  last = true;
             //                                  delete lastPacket;
             //                                  lastPacket = Msg->dup();
             //                       }
    }
    else if(ttmsg->getMsgType() == Form){
//            EV << "Index:"<<getIndex() <<endl <<"CHNUM:"<<CHNum<<endl;

        if(getIndex()==CHNum){
            type = Data;
            KSlotTime = (members +1) * SlotTime;
            emit(stateSignal,type);
//            IDsSlotTime[ttmsg->getSource()] = KSlotTime;
            bubble("Sending TimeSlot");
            temp = getModuleByPath(("node[" + std::to_string(ttmsg->getSource()) + "]").c_str());
                if(!temp)
                    throw cRuntimeError(("node[" + std::to_string(ttmsg->getSource()) + "] not found.").c_str());
                LeachMsg *Msg = generateMessage("Data",getIndex(),ttmsg->getSource());
                Msg->setData(KSlotTime);
//                EV << "Slot Time:" << (Msg->getData()) <<endl;

                sendDirect(Msg, (SetupTime/6),duration,temp->gate("in"));
//                sendDirect(Msg, radioDelay,duration,temp->gate("in"));
//                cancelEvent(endTxEvent);
//                scheduleAt(simTime()+radioDelay+duration, endTxEvent);
                //                       if (transmissionRing != nullptr) {
                //                                  last = true;
                //                                  delete lastPacket;
                //                                  lastPacket = Msg->dup();
                //                       }
        }
        else{
            type = Form;
            emit(stateSignal,type);
            members  = ttmsg->getData();
//            EV << "MEMBERS:" << members <<endl;

//            if(ttmsg->getData() == -1000){
                bubble("Request My TimeSlot");

                 temp = getModuleByPath(("node[" + std::to_string(ttmsg->getSource()) + "]").c_str());
                     if(!temp)
                         throw cRuntimeError(("node[" + std::to_string(ttmsg->getSource()) + "] not found.").c_str());
                     LeachMsg *Msg = generateMessage("Form",getIndex(),ttmsg->getSource());
//                     Msg->setData(-10);
                     sendDirect(Msg, (SetupTime/6),duration,temp->gate("in"));
//                     sendDirect(Msg, radioDelay,duration,temp->gate("in"));
//                     cancelEvent(endTxEvent);
//                     scheduleAt(simTime()+radioDelay+duration, endTxEvent);
                     //                       if (transmissionRing != nullptr) {
                     //                                  last = true;
                     //                                  delete lastPacket;
                     //                                  lastPacket = Msg->dup();
                     //                       }
        }
    }
    else if(ttmsg->getMsgType() == Data){

        if(CHRound){
            type = Data;
            emit(stateSignal,type);
            if(ttmsg->getSource()==ttmsg->getDestination()){
                temp = getModuleByPath("Sink");
                if(!temp)
                    throw cRuntimeError("Sink not found.");
                LeachMsg *SinkMsg = generateMessage("Data",getIndex(),00);
                SinkMsg->setData(ttmsg->getData());

                sendDirect(SinkMsg, radioDelay-(radioDelay/3),radioDelay/3,temp->gate("in"));

                DataCount--;
                if(DataCount >=1) Count = 0;
                if(DataCount == 0){

                     LeachMsg *SelfMsg = generateMessage("Setup",getIndex(),getIndex());

                     scheduleAt((r+1), SelfMsg);
                 }
//                if(DataCount == 0){
//                    //                if(Count==members){
//                    type = Setup;
//                    emit(stateSignal,type);
//                    Candid = false;
//                    LeachMsg *SelfMsg = generateMessage("Setup",getIndex(),CHNum);
//
//                    scheduleAt((r+1) , SelfMsg);//                    type = Idle;
//                }
            }
            else{
            bubble(("Message" + std::to_string(ttmsg->getData()) + "From node[" + std::to_string(ttmsg->getSource()) + "] Received. :)").c_str());

            if(Count < members){
            Count++;
            }
            if(Count == members){
                LeachMsg *SelfMsg = generateMessage("Data",getIndex(),CHNum);

                scheduleAt(simTime(), SelfMsg);

            }
            }

        }
        else{
            type = Data;
            emit(stateSignal,type);
            if(KSlotTime ==0)KSlotTime = ttmsg->getData();
//            EV << "KSlot Time:" << (KSlotTime) <<endl;

            //                bubble("Getting My TimeSlot");
//           Sleep((200-(double)simTime()));
           if(DataCount >= 0){

            temp = getModuleByPath(("node[" + std::to_string(CHNum) + "]").c_str());

            if(!temp)
                throw cRuntimeError(("node[" + std::to_string(CHNum) + "] not found.").c_str());

            LeachMsg *Msg = generateMessage("Data",getIndex(),CHNum);

            Msg->setData(DataCount);

            schedule = GetSchedule();

            LeachMsg *SelfMsg = generateMessage("Data",getIndex(),CHNum);

            cMessage *msg = check_and_cast<cMessage *>(SelfMsg);

            EV << "Next Time:" << (simTime()+(schedule)) <<endl;

            scheduleAt(simTime()+schedule, msg);

            bubble("Waiting For Specific TimeSlot To Send Data");

            if(DefultDataCount != DataCount)sendDirect(Msg, radioDelay,duration,temp->gate("in"));

            DataCount--;
        }
           if(DataCount < 0){
                LeachMsg *SelfMsg = generateMessage("Setup",getIndex(),getIndex());

                scheduleAt((r+1), SelfMsg);
            }

                    //                       if (transmissionRing != nullptr) {
                    //                                  last = true;
                    //                                  delete lastPacket;
                    //                                  lastPacket = Msg->dup();
                    //                       }
//                            }

        }
    }
    else if(ttmsg->getMsgType()==Setup){

             type = Setup;
             emit(stateSignal,type);
             members = 0;
             Candid = false;
             Count = 0;
             CountK =0;
             CHDist=1000;
             DataCount = DefultDataCount;
             CHRound = false;
             CHNum =-1;
             r++;
             KSlotTime =0;
             Candid = SetupPhase();
             CHs = new CH[K];
             CHCands = new CH[N];
             EV << "Candid:" << Candid <<endl;
             //KSlotTime = DefultDataCount * SlotTime;//((1e-4)-SetupTime)/K;
             if(Candid){
                 EV << "K: " << K << ", T(n): " << CalcTn(r, P, Ct) << ", and n : "<< n << endl;
                 for(int i = 0 ; (i< N); i++){
                     temp = getModuleByPath(("node[" + std::to_string(i) + "]").c_str());
                      if(!temp)
                              throw cRuntimeError(("node[" + std::to_string(i) + "] not found.").c_str());

                     if(i!= getIndex()){
                         LeachMsg *Msg = generateMessage("Idle",getIndex(),i);
//                         lastPacket = Msg->dup();
                         cMessage *msg = check_and_cast<cMessage *>(Msg);
          //               scheduleAt(simTime()+radioDelay, msg);
                         scheduleAt((r+1)+(SetupTime/6), msg);
                     }
                 }
                 CHCands[Count].ID = getIndex();
                 Count =1;
             }

 //            CHs = new int[K];
    }
    }
//}

bool Node::SetupPhase(){
    K = CalcKopt(N, e_fs, e_mp, M, D_to_BS);
        r=0;
        n = fmod(rand(), 0.9);//(srand(1),0.9);

        P = CalcP(r, K, N);
        if(n<CalcTn(r, P, Ct)) return true;
        else return false;
}
double Node::GetSchedule(){
    int ClusterNumber;
    for(int i=0;i<K;i++){
        if(CHs[i].ID==CHNum){
            ClusterNumber = i;
        }
    }
    if(DefultDataCount == DataCount){
       return (ClusterNumber*KSlotTime)+(SlotTime*members);
    }
    else{
        return ((N)*SlotTime);
    }
}
void Node::refreshDisplay() const{
    cCanvas *canvas = getParentModule()->getCanvas();
    const int numCircles = Dist/10;
    const double circleLineWidth = Dist/10;

    // create figures on our first invocation
    if (!transmissionRing) {
        auto color = cFigure::GOOD_DARK_COLORS[getId() % cFigure::NUM_GOOD_DARK_COLORS];

        transmissionRing = new cRingFigure(("node[" + std::to_string(getIndex()) + "]Ring").c_str());
        transmissionRing->setOutlined(false);
        transmissionRing->setFillColor(color);
        transmissionRing->setFillOpacity(0.25);
        transmissionRing->setFilled(true);
        transmissionRing->setVisible(false);
        transmissionRing->setZIndex(-1);
        canvas->addFigure(transmissionRing);

        for (int i = 0; i < numCircles; ++i) {
            auto circle = new cOvalFigure(("node[" + std::to_string(getIndex()) + "]Circle" + std::to_string(i)).c_str());
            circle->setFilled(false);
            circle->setLineColor(color);
            circle->setLineOpacity(0.75);
            circle->setLineWidth(circleLineWidth);
            circle->setZoomLineWidth(true);
            circle->setVisible(false);
            circle->setZIndex(-0.5);
            transmissionCircles.push_back(circle);
            canvas->addFigure(circle);
        }
    }

    if (last) {
//        SpinMsg *testM = check_and_cast<SpinMsg *>(lastPacket);
        cModule * TempM= getModuleByPath(("node[" + std::to_string(getIndex()) + "]").c_str());
        double xx = TempM->par("x").doubleValue();
        double yy = TempM->par("y").doubleValue();
//        if(getIndex() == testM->getSource()){
        // update transmission ring and circles
        if (transmissionRing->getAssociatedObject() != lastPacket) {
            transmissionRing->setAssociatedObject(lastPacket);
            for (auto c : transmissionCircles)
                c->setAssociatedObject(lastPacket);
        }

        simtime_t now = simTime();
        simtime_t frontTravelTime = now - lastPacket->getSendingTime();
        simtime_t backTravelTime = now - (lastPacket->getSendingTime() + lastPacket->getArrivalTime());

        // conversion from time to distance in m using speed
        double frontRadius = std::min(ringMaxRadius, frontTravelTime.dbl() * propagationSpeed);
        double backRadius = backTravelTime.dbl() * propagationSpeed;
        double circleRadiusIncrement = circlesMaxRadius / numCircles;

        // update transmission ring geometry and visibility/opacity
        double opacity = 1.0;
        if (backRadius > ringMaxRadius) {
            transmissionRing->setVisible(false);
            transmissionRing->setAssociatedObject(nullptr);
        }
        else {

            transmissionRing->setVisible(true);
            transmissionRing->setBounds(cFigure::Rectangle(xx - frontRadius, yy - frontRadius, 2*frontRadius, 2*frontRadius));
            transmissionRing->setInnerRadius(std::max(0.0, std::min(ringMaxRadius, backRadius)));
            if (backRadius > 0)
                opacity = std::max(0.0, 1.0 - backRadius / circlesMaxRadius);
        }

        transmissionRing->setLineOpacity(opacity);
        transmissionRing->setFillOpacity(opacity/5);

        // update transmission circles geometry and visibility/opacity
        double radius0 = std::fmod(frontTravelTime.dbl() * propagationSpeed, circleRadiusIncrement);
        for (int i = 0; i < (int)transmissionCircles.size(); ++i) {
            double circleRadius = std::min(ringMaxRadius, radius0 + i * circleRadiusIncrement);
            if (circleRadius < frontRadius - circleRadiusIncrement/2 && circleRadius > backRadius + circleLineWidth/2) {
                transmissionCircles[i]->setVisible(true);
                transmissionCircles[i]->setBounds(cFigure::Rectangle(xx - circleRadius, yy - circleRadius, 2*circleRadius, 2*circleRadius));
                transmissionCircles[i]->setLineOpacity(std::max(0.0, 0.2 - 0.2 * (circleRadius / circlesMaxRadius)));
            }
            else
                transmissionCircles[i]->setVisible(false);
        }

        // compute animation speed
        double animSpeed = AnimationSpeed;
        if ((frontRadius >= 0 && frontRadius < circlesMaxRadius) || (backRadius >= 0 && backRadius < circlesMaxRadius))
            animSpeed = AnimationSpeed;
        if (frontRadius > circlesMaxRadius && backRadius < 0)
            animSpeed = AnimationSpeed;
        canvas->setAnimationSpeed(animSpeed, this);
//    }
    }
    else {
        // hide transmission rings, update animation speed
        if (transmissionRing->getAssociatedObject() != nullptr) {
            transmissionRing->setVisible(false);
            transmissionRing->setAssociatedObject(nullptr);

            for (auto c : transmissionCircles) {
                c->setVisible(false);
                c->setAssociatedObject(nullptr);
            }
            canvas->setAnimationSpeed(AnimationSpeed, this);
        }
    }

    // update host appearance (color and text)
    getDisplayString().setTagArg("t", 2, "#808000");
    if (type == Adv) {
        getDisplayString().setTagArg("i", 1, "red");
        getDisplayString().setTagArg("t", 0, "Advertisement");
        }
    else if (type == Join) {
            getDisplayString().setTagArg("i", 1, "yellow");
            getDisplayString().setTagArg("t", 0, "Join Request");
        }
    else if (type == Form) {
            getDisplayString().setTagArg("i", 1, "blue");
            getDisplayString().setTagArg("t", 0, "Formed");
        }
    else if (type == Data) {
            getDisplayString().setTagArg("i", 1, "black");
            getDisplayString().setTagArg("t", 0, "Data Exchange :)");
        }
    else if (type == Idle) {
            getDisplayString().setTagArg("i", 1, "");
            getDisplayString().setTagArg("t", 0, "Idle");
        }
    else if (type == Setup) {
            getDisplayString().setTagArg("i", 1, "green");
            getDisplayString().setTagArg("t", 0, "Setup");
        }

}
void Node::finish(){
    last = false;
    EV << "duration: " << simTime() <<endl;
}
LeachMsg *Node::generateMessage(std::string Type,int src,int dest){
    char msgname[60];
    sprintf(msgname, "node-%d-to-%d", src, dest);

    LeachMsg *msg = new LeachMsg(msgname);
    msg->setSource(src);
    msg->setDestination(dest);
//    msg->setSender(sender);
//    msg->setReciver(reciver);
    if(Type == "Adv"){
        msg->setMsgType(1);
       // msg->setHopCount(msg->getHopCount()+1);
    }
    else if(Type == "Join"){
        msg->setMsgType(2);
      //  msg->setHopCount(msg->getHopCount()-1);
    }
    else if(Type == "Form"){
        msg->setMsgType(3);
     //   msg->setHopCount(msg->getHopCount()+1);
        msg->setData(intuniform(0, 10000));
    }
    else if(Type == "Data"){
        msg->setMsgType(4);
     //   msg->setHopCount(msg->getHopCount()+1);
        msg->setData(intuniform(0, 10000));
    }
    else if(Type == "Setup"){
        msg->setMsgType(5);
     //   msg->setHopCount(msg->getHopCount()+1);
        msg->setData(intuniform(0, 10000));
    }
    return msg;
}

class BS : public cSimpleModule{
private:

public:
    BS();
    virtual ~BS();

protected:
//    virtual SpinMsg *generateMessage(std::string Type, int sender,int reciver, int src,int dest);
//    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
//    virtual void refreshDisplay() const override;
//    virtual void finish() override;
};
Define_Module(BS);
BS::BS(){

}
BS::~BS(){

}


void BS::handleMessage(cMessage *msg){
    bubble("Data Delivered :)");
}

