/*
 * SP.cc
 *
 *  Created on: Mar 30, 2019
 *      Author: arman
 */

#include <string.h>
#include <omnetpp.h>
#include <algorithm>
#include "Spin_m.h"
using namespace omnetpp;

class Node : public cSimpleModule{
private:
    simtime_t radioDelay;
//    cPar *pkLenBits;
    cModule *temp;
//    SpinMsg *Msg;
    cMessage *endTxEvent;

    enum{Idle = 0, Adv = 1, Req = 2, Data = 3,Recv=4}type;
    simsignal_t stateSignal;
    simtime_t duration;
    simtime_t events;
//    const int numNode = par("numNodes");
    int numNodes;// = 6;
    int *database;// = new int[numNode];
//    int HopCount;
    double x, y;
    double txRate;
    const double propagationSpeed = 299792458.0;
     double Dist;

    /* Graphical Variables */
     double ringMaxRadius;// = 200;// = par("Distance");// in m
     double circlesMaxRadius;// = 250;// = par("Distance"); // in m
     double AnimationSpeed ;// = par("AnimationSpeed");
    cMessage *lastPacket = nullptr; // a copy of the last sent message, needed for animation
    bool last ;
    mutable cRingFigure *transmissionRing = nullptr; // shows the last packet
    mutable std::vector<cOvalFigure *> transmissionCircles; // ripples inside the packet ring

public:
    Node();
    virtual ~Node();

protected:
    virtual SpinMsg *generateMessage(std::string Type, int sender,int reciver, int src,int dest);
    virtual void initialize() override;
    virtual void handleMessage(cMessage *msg) override;
    virtual void refreshDisplay() const override;
    virtual void finish() override;
};

Define_Module(Node);

Node::Node(){
    endTxEvent = nullptr;

}
Node::~Node(){
    delete lastPacket;
    cancelAndDelete(endTxEvent);
}
void Node::initialize(){
    last =false;
    type = Idle;
    numNodes = par("numNodes");
    database = new int[numNodes];
    ringMaxRadius = par("Distance");// in m
    circlesMaxRadius = par("Distance"); // in m
    AnimationSpeed = par("AnimationSpeed");
    Dist = par("Distance");
    txRate = par("txRate");
    database[getIndex()] = numNodes;
    radioDelay = Dist / propagationSpeed;
    duration = 0;
    endTxEvent = new cMessage("send/endTx");

    if (getIndex() == 0) {
        int reciver=getIndex();
        while(reciver == getIndex()){
            reciver = intuniform(0, numNodes-1);
        }
        reciver=6;
        stateSignal = registerSignal("state");
        emit(stateSignal,type);
        WATCH((int&)type);
        x = par("x").doubleValue();
        y = par("y").doubleValue();
        database[getIndex()] = getIndex();

        for(int i = 1 ; i< numNodes; i++){
            temp = getModuleByPath(("node[" + std::to_string(i) + "]").c_str());
             if(!temp)
                     throw cRuntimeError(("node[" + std::to_string(i) + "] not found.").c_str());
             double XT = temp->par("x").doubleValue();
             double YT = temp->par("y").doubleValue();
             double Tdist = std::sqrt((x-XT) * (x-XT) + (y-YT) * (y-YT));
                 if(Dist >= Tdist){
             SpinMsg *Msg = generateMessage("Idle",getIndex(),reciver,getIndex(),i);
             lastPacket = Msg->dup();
             cMessage *msg = check_and_cast<cMessage *>(Msg);
             scheduleAt(simTime()+radioDelay, msg);
                 }
        }
    }
}
void Node::handleMessage(cMessage *msg){
    last = false;
    ASSERT(msg == endTxEvent);
    if(msg!=endTxEvent){
    SpinMsg *ttmsg = check_and_cast<SpinMsg *>(msg);
    if(ttmsg->getMsgType() == Idle && ttmsg->getSender() == getIndex() && ttmsg->getSource()==getIndex()){
            type = Adv;
            emit(stateSignal,type);
            temp = getModuleByPath(("node[" + std::to_string(ttmsg->getDestination()) + "]").c_str());
                  if(!temp)
                     throw cRuntimeError(("node[" + std::to_string(ttmsg->getDestination()) + "] not found.").c_str());

                  SpinMsg *Msg = generateMessage("Adv",ttmsg->getSender(),ttmsg->getReciver(),getIndex(),ttmsg->getDestination());
                  sendDirect(Msg, radioDelay,duration,temp->gate("in"));
                  cancelEvent(endTxEvent);
                  scheduleAt(simTime()+radioDelay+duration, endTxEvent);

                  if (transmissionRing != nullptr) {
                          last = true;
                              delete lastPacket;
                              lastPacket = Msg->dup();
                          }
        }

    else if(ttmsg->getMsgType() == Adv){
    if(ttmsg->getSender() != database[getIndex()]){
        std::string tempstr = "Interested to node[" + std::to_string(ttmsg->getSource()) + "] message.";
        database[getIndex()] = ttmsg->getSender();
        SpinMsg *Msg = generateMessage("Req",ttmsg->getSender(),ttmsg->getReciver(),getIndex(),ttmsg->getSource());
        type = Req;
        temp = getModuleByPath( ("node[" + std::to_string(ttmsg->getSource()) + "]").c_str());
        sendDirect(Msg, radioDelay,duration,temp->gate("in"));
        cancelEvent(endTxEvent);

        scheduleAt(simTime()+radioDelay+duration, endTxEvent);

        bubble(tempstr.c_str());
        if (transmissionRing != nullptr) {
            last = true;
                    delete lastPacket;
                    lastPacket = Msg->dup();
                }
    }
    else{
//        std::string tempstr = "Not Interested to node[" + std::to_string(ttmsg->getSource()) + "] message.";
//        bubble(tempstr.c_str());
        }
    }
    else if(ttmsg->getMsgType() == Req){

        SpinMsg *Msg = generateMessage("Data",ttmsg->getSender(),ttmsg->getReciver(), getIndex(),ttmsg->getSource());
        type = Data;
        temp = getModuleByPath( ("node[" + std::to_string(ttmsg->getSource()) + "]").c_str());
        sendDirect(Msg, radioDelay,duration,temp->gate("in"));
        cancelEvent(endTxEvent);
        scheduleAt(simTime()+radioDelay+duration, endTxEvent);
               if (transmissionRing != nullptr) {
                           last = true;
                           delete lastPacket;
                           lastPacket = Msg->dup();
                       }
    }
    else if(ttmsg->getMsgType() == Data){
        if(getIndex() == ttmsg->getReciver()){
            bubble("Message Received successfully");
            cancelEvent(endTxEvent);
            last = false;
            type = Recv;
        }
        else{
            x = par("x").doubleValue();
            y = par("y").doubleValue();
            for(int i = 0 ; i< numNodes; i++){
                temp = getModuleByPath(("node[" + std::to_string(i) + "]").c_str());
                 if(!temp)
                         throw cRuntimeError(("node[" + std::to_string(i) + "] not found.").c_str());
                 double XT = temp->par("x").doubleValue();
                 double YT = temp->par("y").doubleValue();
                 double Tdist = std::sqrt((x-XT) * (x-XT) + (y-YT) * (y-YT));
                     if(Dist >= Tdist){
                         SpinMsg *Msg = generateMessage("Adv",ttmsg->getSender(),ttmsg->getReciver(),getIndex(),i);
                         sendDirect(Msg, radioDelay,duration,temp->gate("in"));
                         cancelEvent(endTxEvent);
                         scheduleAt(simTime()+radioDelay+duration, endTxEvent);

                           if (transmissionRing != nullptr) {
                               last = true;
                        delete lastPacket;
                        lastPacket = Msg->dup();
                           }
                     }

                }
            type = Adv;
            }
        }
    }
}
void Node::refreshDisplay() const{
    cCanvas *canvas = getParentModule()->getCanvas();
    const int numCircles = Dist/10;
    const double circleLineWidth = Dist/10;

    // create figures on our first invocation
    if (!transmissionRing) {
        auto color = cFigure::GOOD_DARK_COLORS[getId() % cFigure::NUM_GOOD_DARK_COLORS];

        transmissionRing = new cRingFigure(("node[" + std::to_string(getIndex()) + "]Ring").c_str());
        transmissionRing->setOutlined(false);
        transmissionRing->setFillColor(color);
        transmissionRing->setFillOpacity(0.25);
        transmissionRing->setFilled(true);
        transmissionRing->setVisible(false);
        transmissionRing->setZIndex(-1);
        canvas->addFigure(transmissionRing);

        for (int i = 0; i < numCircles; ++i) {
            auto circle = new cOvalFigure(("node[" + std::to_string(getIndex()) + "]Circle" + std::to_string(i)).c_str());
            circle->setFilled(false);
            circle->setLineColor(color);
            circle->setLineOpacity(0.75);
            circle->setLineWidth(circleLineWidth);
            circle->setZoomLineWidth(true);
            circle->setVisible(false);
            circle->setZIndex(-0.5);
            transmissionCircles.push_back(circle);
            canvas->addFigure(circle);
        }
    }

    if (last) {
//        SpinMsg *testM = check_and_cast<SpinMsg *>(lastPacket);
        cModule * TempM= getModuleByPath(("node[" + std::to_string(getIndex()) + "]").c_str());
        double xx = TempM->par("x").doubleValue();
        double yy = TempM->par("y").doubleValue();
//        if(getIndex() == testM->getSource()){
        // update transmission ring and circles
        if (transmissionRing->getAssociatedObject() != lastPacket) {
            transmissionRing->setAssociatedObject(lastPacket);
            for (auto c : transmissionCircles)
                c->setAssociatedObject(lastPacket);
        }

        simtime_t now = simTime();
        simtime_t frontTravelTime = now - lastPacket->getSendingTime();
        simtime_t backTravelTime = now - (lastPacket->getSendingTime() + lastPacket->getArrivalTime());

        // conversion from time to distance in m using speed
        double frontRadius = std::min(ringMaxRadius, frontTravelTime.dbl() * propagationSpeed);
        double backRadius = backTravelTime.dbl() * propagationSpeed;
        double circleRadiusIncrement = circlesMaxRadius / numCircles;

        // update transmission ring geometry and visibility/opacity
        double opacity = 1.0;
        if (backRadius > ringMaxRadius) {
            transmissionRing->setVisible(false);
            transmissionRing->setAssociatedObject(nullptr);
        }
        else {

            transmissionRing->setVisible(true);
            transmissionRing->setBounds(cFigure::Rectangle(xx - frontRadius, yy - frontRadius, 2*frontRadius, 2*frontRadius));
            transmissionRing->setInnerRadius(std::max(0.0, std::min(ringMaxRadius, backRadius)));
            if (backRadius > 0)
                opacity = std::max(0.0, 1.0 - backRadius / circlesMaxRadius);
        }

        transmissionRing->setLineOpacity(opacity);
        transmissionRing->setFillOpacity(opacity/5);

        // update transmission circles geometry and visibility/opacity
        double radius0 = std::fmod(frontTravelTime.dbl() * propagationSpeed, circleRadiusIncrement);
        for (int i = 0; i < (int)transmissionCircles.size(); ++i) {
            double circleRadius = std::min(ringMaxRadius, radius0 + i * circleRadiusIncrement);
            if (circleRadius < frontRadius - circleRadiusIncrement/2 && circleRadius > backRadius + circleLineWidth/2) {
                transmissionCircles[i]->setVisible(true);
                transmissionCircles[i]->setBounds(cFigure::Rectangle(xx - circleRadius, yy - circleRadius, 2*circleRadius, 2*circleRadius));
                transmissionCircles[i]->setLineOpacity(std::max(0.0, 0.2 - 0.2 * (circleRadius / circlesMaxRadius)));
            }
            else
                transmissionCircles[i]->setVisible(false);
        }

        // compute animation speed
        double animSpeed = AnimationSpeed;
        if ((frontRadius >= 0 && frontRadius < circlesMaxRadius) || (backRadius >= 0 && backRadius < circlesMaxRadius))
            animSpeed = AnimationSpeed;
        if (frontRadius > circlesMaxRadius && backRadius < 0)
            animSpeed = AnimationSpeed;
        canvas->setAnimationSpeed(animSpeed, this);
//    }
    }
    else {
        // hide transmission rings, update animation speed
        if (transmissionRing->getAssociatedObject() != nullptr) {
            transmissionRing->setVisible(false);
            transmissionRing->setAssociatedObject(nullptr);

            for (auto c : transmissionCircles) {
                c->setVisible(false);
                c->setAssociatedObject(nullptr);
            }
            canvas->setAnimationSpeed(AnimationSpeed, this);
        }
    }

    // update host appearance (color and text)
    getDisplayString().setTagArg("t", 2, "#808000");
    if (type == Adv) {
        getDisplayString().setTagArg("i", 1, "red");
        getDisplayString().setTagArg("t", 0, "Advertisement");
        }
    else if (type == Req) {
            getDisplayString().setTagArg("i", 1, "yellow");
            getDisplayString().setTagArg("t", 0, "Request");
        }
    else if (type == Data) {
            getDisplayString().setTagArg("i", 1, "blue");
            getDisplayString().setTagArg("t", 0, "Data");
        }
    else if (type == Recv) {
            getDisplayString().setTagArg("i", 1, "black");
            getDisplayString().setTagArg("t", 0, "Message Received :)");
        }
    else if (type == Idle) {
            getDisplayString().setTagArg("i", 1, "");
            getDisplayString().setTagArg("t", 0, "");
        }

}
void Node::finish(){
    last = false;
    EV << "duration: " << simTime() <<endl;
}
SpinMsg *Node::generateMessage(std::string Type, int sender,int reciver, int src,int dest){
    char msgname[60];
    sprintf(msgname, "%s",Type.c_str());//"node-%d-to-%d-(sender=%d,receiver=%d", src, dest,sender,reciver);

    SpinMsg *msg = new SpinMsg(msgname);
    msg->setSource(src);
    msg->setDestination(dest);
    msg->setSender(sender);
    msg->setReciver(reciver);
    if(Type == "Adv"){
        msg->setMsgType(1);
        msg->setHopCount(msg->getHopCount()+1);
    }
    else if(Type == "Req"){
        msg->setMsgType(2);
        msg->setHopCount(msg->getHopCount()-1);
    }
    else if(Type == "Data"){
        msg->setMsgType(3);
        msg->setHopCount(msg->getHopCount()+1);
        msg->setData(intuniform(0, 10000));
    }
    return msg;
}
